<?php

defined('ADMIN_MODULE_NAME') or define('ADMIN_MODULE_NAME', 'stahiev.upbutton');

require_once($_SERVER['DOCUMENT_ROOT'] . '/local/modules/' . ADMIN_MODULE_NAME . '/lib/stahiev_params.php');

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;

//Что хочу:
//1. Активация кнопки (показ)
//2. Позиция кнопки (лево-право, снизу)
//3. Цвет кнопки

CJSCore::Init(array("jquery"));
$APPLICATION->SetAdditionalCSS('/local/css/' . ADMIN_MODULE_NAME . '/style.css');
$APPLICATION->AddHeadScript('/local/js/' . ADMIN_MODULE_NAME . '/scripts.js');

if (!$USER->isAdmin()) {
    $APPLICATION->authForm('Nope');
}

$app = Application::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

$arrayColors = stahiev_params::$getColor;
$arrayPositions = stahiev_params::$positions;

Loc::loadMessages($context->getServer()->getDocumentRoot() . "/bitrix/modules/main/options.php");
Loc::loadMessages(__FILE__);

$tabControl = new CAdminTabControl("tabControl", array(
    array(
        "DIV" => "edit1",
        "TAB" => Loc::getMessage("MAIN_TAB_SET"),
        "TITLE" => Loc::getMessage("MAIN_TAB_TITLE_SET"),
    )
));

if ((!empty($save) || !empty($restore) || !empty($request->getPost('create'))) && $request->isPost() && check_bitrix_sessid()) {
    if (!empty($restore)) {
        Option::delete(ADMIN_MODULE_NAME);
        CAdminMessage::showMessage(array(
            "MESSAGE" => Loc::getMessage("REFERENCES_OPTIONS_RESTORED"),
            "TYPE" => "OK",
        ));
    } else {
        Option::set(
            ADMIN_MODULE_NAME,
            "active_button",
            (($request->getPost('active_button')) ? 1 : 0)
        );
        Option::set(
            ADMIN_MODULE_NAME,
            "position",
            ((!empty($request->getPost('position'))) ? serialize($request->getPost('position')) : "''")
        );

        Option::set(
            ADMIN_MODULE_NAME,
            "button_color",
            $request->getPost('button_color')
        );

        CAdminMessage::showMessage(array(
            "MESSAGE" => Loc::getMessage("REFERENCES_OPTIONS_SAVED"),
            "TYPE" => "OK",
        ));
        if ($request->getPost('create')) {
            $export = new RssExport();
            if ($export->export()) {
                CAdminMessage::showMessage(array(
                    "MESSAGE" => Loc::getMessage("STAHIEV_EXPORT_COMPLETE"),
                    "TYPE" => "OK",
                ));
            } else {
                CAdminMessage::showMessage(array(
                    "MESSAGE" => Loc::getMessage("STAHIEV_EXPORT_ERROR"),
                    "TYPE" => "ERROR",
                ));
            }
        }
    }
}

$tabControl->begin();
?>
<form method="post" class="stahiev-upbutton" enctype="multipart/form-data" action="<?= sprintf('%s?mid=%s&lang=%s', $request->getRequestedPage(), urlencode($mid), LANGUAGE_ID) ?>">
    <?= bitrix_sessid_post(); ?>
    
    <? $tabControl->beginNextTab(); ?>
    <tr>
        <td width="40%">
            <label for="active_button"><?= Loc::getMessage("STAHIEV_ACTIVE_BUTTON") ?>: </label>
        </td>
        <td width="60%">
            <input type="checkbox" id="active_button" name="active_button" value="1" <?= ((Option::get(ADMIN_MODULE_NAME, "active_button")) ? " checked='checked'" : ""); ?> />
        </td>
    </tr>

    <tr>
        <td width="40%">
            <?= Loc::getMessage("STAHIEV_POSITION_LABEL") ?>
        </td>
        <td width="60%">
            <select name="position">
                <? foreach ($arrayPositions as $position) : ?>
                    <option value="down-<?= $position; ?>" <?= $request->getPost('position') == "down-" . $position ? " selected" : ""; ?>><?= Loc::getMessage("STAHIEV_BUTTON_" . strtoupper($position) . "_DOWN"); ?></option>
                <? endforeach; ?>
            </select>
        </td>
    </tr>
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <label for="button_color"><?= Loc::getMessage("STAHIEV_COLOR_SELECT") ?></label>
        </td>
        <td width="60%">
            <select name="button_color">
                <? foreach ($arrayColors as $color) : ?>
                    <option value="<?= $color; ?>" <?= $request->getPost('button_color') == $color ? " selected" : ""; ?>><?= Loc::getMessage("STAHIEV_BUTTON_COLOR_" . strtoupper($color)); ?></option>
                <? endforeach; ?>
            </select>
        </td>
    </tr>

    <? $tabControl->buttons(); ?>
    <input type="submit" name="save" value="<?= Loc::getMessage("MAIN_SAVE") ?>" title="<?= Loc::getMessage("MAIN_OPT_SAVE_TITLE") ?>" class="adm-btn-save" />
    <input type="submit" name="restore" title="<?= Loc::getMessage("MAIN_HINT_RESTORE_DEFAULTS") ?>" onclick="return confirm('<?= AddSlashes(GetMessage("MAIN_HINT_RESTORE_DEFAULTS_WARNING")) ?>')" value="<?= Loc::getMessage("MAIN_RESTORE_DEFAULTS") ?>" />
    <? $tabControl->end(); ?>
</form>