<? $arModuleVersion = array(
    "VERSION" => "1.0.1",
    "VERSION_DATE" => "2018-06-23 12:28:17"
);
