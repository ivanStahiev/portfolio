<?

use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;

Loc::loadMessages(__FILE__);

class stahiev extends CModule
{
    var $MODULE_ID = 'stahiev';
    var $MODULE_NAME = Loc::getMessage('STAHIEV_MODUL_NAME');

    public function __construct()
    {
        $arModuleVersion = array();

        include __DIR__ . '/version.php';

        if (is_array($arModuleVersion) && array_key_exists('VERSION', $arModuleVersion)) {
            $this->MODULE_VERSION = $arModuleVersion['VERSION'];
            $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        }

        $this->MODULE_ID = 'stahiev';
        $this->MODULE_NAME = Loc::getMessage('STAHIEV_MODUL_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('STAHIEV_MODUL_DESCRIPTION');
        $this->MODULE_GROUP_RIGHTS = 'N';
        $this->PARTNER_NAME = Loc::getMessage('STAHIEV_MODULE_PARTNER_NAME');
        $this->PARTNER_URI = Loc::getMessage('STAHIEV_MODULE_PARTNER_URL');
    }

    function InstallDB($install_wizard = true)
    {
        RegisterModule("stahiev");

        return true;
    }

    function UnInstallDB($arParams = array())
    {
        UnRegisterModule("stahiev");

        return true;
    }

    public function DoInstall()
    {
        $this->InstallFiles();
        $this->InstallDB(false);
    }

    public function DoUninstall()
    {
        $this->UnInstallDB(false);
    }
    function InstallFiles($arParams = array())
    {
        return true;
    }
    function UnInstallFiles($arParams = array())
    {
        return true;
    }
}
