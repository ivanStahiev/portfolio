<?
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['REFERENCES_OPTIONS_RESTORED'] = "Восстановлены настройки по умолчанию";
$MESS['REFERENCES_OPTIONS_SAVED'] = "Настройки сохранены";
$MESS['STAHIEV_EXPORT_COMPLETE'] = "Настройки обновлены";
$MESS['STAHIEV_EXPORT_ERROR'] = "Выгрузка ленты произведена с ошибкой. Обратитесь, пожалуйста, в службу поддержки модуля";

$MESS['STAHIEV_CREATE'] = "Выгрузить";
$MESS['STAHIEV_CREATE_TITLE'] = "Сохранить и выгрузить";

$MESS['STAHIEV_POSITION_LABEL'] = "Расположение кнопки";
$MESS['STAHIEV_ACTIVE_BUTTON'] = "Показывать/скрывать кнопку";
$MESS['STAHIEV_COLOR_SELECT'] = "Выбрать цвет кнопки";

$MESS['STAHIEV_BUTTON_LEFT_DOWN'] = "Слева, снизу";
$MESS['STAHIEV_BUTTON_RIGHT_DOWN'] = "Справа, снизу";

$MESS['STAHIEV_BUTTON_COLOR_RED'] = "Красный";
$MESS['STAHIEV_BUTTON_COLOR_GREEN'] = "Зеленый";
$MESS['STAHIEV_BUTTON_COLOR_BLUE'] = "Синий";
