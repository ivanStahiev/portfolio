<? $MESS['STAHIEV_MODULE_NAME'] = 'Стахиев: кнопка вверх';
$MESS['STAHIEV_MODUL_DESCRIPTION'] = 'Описание для модуля "Стахиев: кнопка вверх"';
$MESS['STAHIEV_MODULE_PARTNER_NAME'] = 'stahiev';
$MESS['STAHIEV_MODULE_PARTNER_URL'] = 'https://stahiev.ru';
