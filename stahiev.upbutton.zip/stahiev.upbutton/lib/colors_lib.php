<?
class stahiev_params
{
    public static $getColor = array('red', 'green', 'blue');
    public static $positions = array('left', 'right');
}
