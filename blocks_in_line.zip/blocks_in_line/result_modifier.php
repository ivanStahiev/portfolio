<?php

use Bitrix\Main\Loader;

Loader::IncludeModule('highloadblock');
use Bitrix\Highloadblock as HL;
use Bitrix\Main\Entity;

if (!empty($arResult['ITEMS'])) {
    if (!empty($arParams['PARENT_SECTION']) || !empty($arParams['PARENT_SECTION_CODE'])) {
        $arResult['FULL'] = "Y";
        if (!empty($arParams['PARENT_SECTION'])) {
            $getSection = CIBlockSection::GetList(array(), array("IBLOCK_ID" => $arParams['IBLOCK_ID'], "ACTIVE" => "Y", "ID" => $arParams['PARENT_SECTION']), false, array("UF_FULL_WIDTH", "UF_SLIDER", "UF_SHOW_TITLE"))->GetNext();
            if (!empty($getSection['UF_FULL_WIDTH']) && $getSection['UF_FULL_WIDTH'] == "1") {
                $arResult['WIDTH_MODE'] = "full";
            }
            if (!empty($getSection['UF_SHOW_TITLE'])) {
                $arResult['SHOW_TITLE'] = $getSection['NAME'];
            }
            if (!empty($getSection['CODE'])) {
                $arResult['SECT_CODE'] = $getSection['CODE'];
            }
        }
    }
    foreach ($arResult['ITEMS'] as &$item) {
        if (!empty($item['PROPERTIES']['SELECT_PAGE']['VALUE'])) { ?>
            <? $hlblockRes = HL\HighloadBlockTable::getList([
                'filter' => ['=NAME' => "LinksListHLB"]
            ])->fetch();
            if ($hlblockRes) {
                $hlblock = HL\HighloadBlockTable::getById($hlblockRes['ID'])->fetch();
                $entity = HL\HighloadBlockTable::compileEntity($hlblock);
                $entity_data_class = $entity->getDataClass();
                //Надо проверить, нет ли в таблице пунктов меню, которые удалены
                $resL = $entity_data_class::getList(array('filter' => array(
                    '=UF_XML_ID' => $item['PROPERTIES']['SELECT_PAGE']['VALUE']
                ), 'select' => array('UF_LINK')));
                $resArrDel = array();
                while ($res = $resL->Fetch()) {
                    $item['LINK'] = $res['UF_LINK'];
                    if (!empty($item['PROPERTIES']['LINK']['VALUE'])) {
                        $item['LINK'] = $item['PROPERTIES']['LINK']['VALUE'];
                    }
                }
            }; ?>
        <? } else {
            if (!empty($item['PROPERTIES']['LINK']['VALUE'])) {
                $item['LINK'] = $item['PROPERTIES']['LINK']['VALUE'];
            }
        }
    }
}