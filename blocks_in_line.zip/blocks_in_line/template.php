<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<section<? if (!empty($arResult['WIDTH_MODE']) && $arResult['WIDTH_MODE'] == "full"): ?> class="cup"<? endif; ?><?= !empty($arParams['ID_BLOCK_VALUE']) ? " id='" . $arParams['ID_BLOCK_VALUE'] . "'" : ""; ?>>
    <? if (!empty($arResult['SHOW_TITLE'])): ?>
        <h3><?= $arResult['SHOW_TITLE']; ?></h3>
    <? endif; ?>
    <div
        class="cards row-items-<?= $arParams['NEWS_COUNT_ROW']; ?><?= $arParams['USE_SLIDER'] == "Y" ? " owl-carousel owl-theme" : "" ?>">
        <? foreach ($arResult["ITEMS"] as $arItem): ?>
            <?
            $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
            $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
            ?>
            <? if (!empty($arItem['LINK'])): ?>
                <a href="<?= $arItem['LINK']; ?>" id="<?= $this->GetEditAreaId($arItem['ID']); ?>"
                   class="content"
                   title="<?= $arItem['NAME']; ?>">
                    <div class="img-container"
                         data-source="<?= CFile::GetPath($arItem['PROPERTIES']['FILE']['VALUE']); ?>"></div>
                    <h3><?= $arItem['NAME']; ?></h3>
                    <p><?= $arItem['PREVIEW_TEXT']; ?></p>
                </a>
            <? else: ?>
                <div class="content" id="<?= $this->GetEditAreaId($arItem['ID']); ?>">
                    <div class="img-container"
                         data-source="<?= CFile::GetPath($arItem['PROPERTIES']['FILE']['VALUE']); ?>"></div>
                    <h3><?= $arItem['NAME']; ?></h3>
                    <p><?= $arItem['PREVIEW_TEXT']; ?></p>
                </div>
            <? endif; ?>
        <? endforeach; ?>
    </div>
</section>