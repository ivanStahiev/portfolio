<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arResult['POSITION_BUTTON_STYLE'] = 'right: 50px; left: auto;';
if (!empty($arResult['POSITION_BUTTON'])) {
    if ($arResult['POSITION_BUTTON'] == "down-left") {
        $arResult['POSITION_BUTTON_STYLE'] = 'left: 50px; right: auto;';
    }
}
