$(window).scroll(function () {
    if ($(this).scrollTop() > 700) {
        $('.stahiev-btn-up').fadeIn();
    } else {
        $('.stahiev-btn-up').fadeOut();
    }
});
$(document).on('click', 'a[href="#pageup"]', function () {
    event.preventDefault();
    $("body,html").animate({
        scrollTop: 0
    }, 800);
    return false;
});