<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<div class="stahiev-btn-up<?= !empty($arResult['IMAGE_SRC']) ? ' img-add-bg' : ''; ?>" style="<?= (!empty($arResult['IMAGE_SRC']) ? 'background-image: url(' . $arResult['IMAGE_SRC'] . '); ' : '') . $arResult['POSITION_BUTTON_STYLE']; ?>">
    <a href="#pageup" <?= !empty($arResult['COLOR_BUTTON']) ? ('style="color: ' . $arResult['COLOR_BUTTON'] . '; "') : '' ?>><i class="fa fa-arrow-up"></i></a>
</div>