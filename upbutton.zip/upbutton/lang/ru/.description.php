<?
$MESS ['UP_BUTTON_COMPONENT_NAME'] = "Кнопка наверх";
$MESS ['UP_BUTTON_COMPONENT_DESCR'] = "Кнопка, при нажатии на которую происходит прокрутка страницы в начало";
