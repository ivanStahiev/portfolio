<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = array(
    "NAME" => GetMessage("UP_BUTTON_COMPONENT_NAME"),
    "DESCRIPTION" => GetMessage("UP_BUTTON_COMPONENT_DESCR"),
    "PATH" => array(
        "ID" => "utility"
    )
);
