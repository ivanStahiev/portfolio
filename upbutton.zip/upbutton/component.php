<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$active_btn = COption::GetOptionString("stahiev.upbutton", "active_button");
$position = unserialize(COption::GetOptionString("stahiev.upbutton", "position"));
$color = COption::GetOptionString("stahiev.upbutton", "button_color");

if ($active_btn) {
    $arResult['POSITION_BUTTON'] = $position;
    $arResult['COLOR_BUTTON'] = $color;
    if ($arParams['USE_IMAGE'] == "Y" && !empty($arParams['IMAGE'])) {
        $arResult['IMAGE_SRC'] = $arParams['IMAGE'];
    }
} else {
    return;
}

$this->IncludeComponentTemplate();
