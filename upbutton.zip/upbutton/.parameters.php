<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = array(
    "PARAMETERS" => array(
        "USE_IMAGE" => array(
            "NAME" => GetMessage("USE_IMAGE_BUTTON"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
            "PARENT" => "BASE",
            "REFRESH" => "Y"
        )
    )
);

if ($arCurrentValues['USE_IMAGE'] == "Y") {
    $arComponentParameters['PARAMETERS']['IMAGE'] = array(
        "NAME" => GetMessage("IMAGE_BUTTON"),
        "TYPE" => "FILE",
        "FD_UPLOAD" => true,
        "FD_TARGET" => "F",
        "FD_USE_MEDIALIB" => true,
        "PARENT" => "BASE",
    );
}
