<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
$APPLICATION->SetTitle("Тесты");
?>
<style>
    html,
    body {
        overflow: auto;
    }
</style>
<?  ?>
<? require($_SERVER["DOCUMENT_ROOT"] . '/local/php_interface/classes/stahiev_cookies.php'); ?>
<?

use stahiev\cookies\cookie_operations;
use stahiev\cookies\cookie_statuses;
?>

<? $cookie = new cookie_operations(); ?>

<? $cookiesCheck = $cookie->get('cookiesSave'); ?>

<? $statusCookie = new cookie_statuses('cookiesSave'); ?>
<? $checkStatus = $statusCookie->checkStatusCookie(); ?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <?
            if ($checkStatus == 'new') : ?>
                <div class="cookies-warning">
                    Всем привет! Это тест Cookies.
                    Чтобы продолжить, нажмите "Записать Cookies".
                    <form action="" method="POST">
                        <input type="submit" name="good" value="Записать Cookies">
                    </form>
                </div>
            <?
            elseif ($checkStatus == 'written') : ?>
                <div class="cookies-warning">
                    Cookies успешно записаны (на 2 минуты).
                    Но вы можете их удалить.
                    Нажмите "Удалить".
                    <form action="" method="POST">
                        <input type="submit" name="nogood" value="Удалить">
                    </form>
                </div>
            <?
            elseif ($checkStatus == 'write') : ?>
                <div class="cookies-warning">
                    Идет процесс записи.
                    Но вы можете отменить статус записи Cookies.
                    Нажмите "Отменить".
                    <form action="" method="POST">
                        <input type="submit" name="nogood" value="Отменить">
                        <input type="submit" name="next" value="Продолжить">
                    </form>
                </div>
            <?
            elseif ($checkStatus == 'deletion') : ?>
                <div class="cookies-warning">
                    Cookies успешно удалены.
                    Но вы можете записать их снова.
                    Нажмите "Снова записать".
                    <form action="" method="POST">
                        <input type="submit" name="good" value="Снова записать">
                    </form>
                </div>
            <?
            elseif ($checkStatus == 'delete') : ?>
                <div class="cookies-warning">
                    Идет процесс удаления Cookies.
                    Но вы можете отменить.
                    Нажмите "Отменить удаление".
                    <form action="" method="POST">
                        <input type="submit" name="good" value="Отменить удаление">
                        <input type="submit" name="next" value="Продолжить">
                    </form>
                </div>
            <? else : ?>
                <div class="cookies-warning">
                    Всем привет! Это тест Cookies.
                    Чтобы продолжить, нажмите "Записать Cookies".
                    <form action="" method="POST">
                        <input type="submit" name="good" value="Записать Cookies">
                    </form>
                </div>
            <? endif; ?>

        </div>
    </div>
</div>
<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>