<?php

namespace stahiev\cookies;

abstract class cookie
{
    public $time;
    public $anti;
    public $path;

    public function __construct($time = "", $anti = "", $path = "")
    {
        $this->time = time() + 120;
        $this->anti = time() - 120;
        $this->path = "/";
    }

    abstract function set($name, $value, $time = "", $path = "");
    abstract function del($name, $anti = "", $path = "", $domain = "");
    abstract function get($name);
}

class cookie_operations extends cookie
{
    public $time;
    public $anti;
    public $path;

    public function __construct()
    {
        parent::__construct();
    }

    public function set($name, $value, $timeSet = "", $pathSet = "")
    {
        if (empty($timeSet)) {
            $timeSet = $this->time;
        }
        if (empty($pathSet)) {
            $pathSet = $this->path;
        }

        return setcookie($name, $value, $timeSet, $pathSet);
    }

    public function del($name, $antiSet = "", $pathSet = "", $domain = "")
    {
        if (empty($antiSet)) {
            $antiSet = $this->anti;
        }
        if (empty($pathSet)) {
            $pathSet = $this->path;
        }

        return setcookie($name, "", $antiSet, $pathSet);
    }

    public function get($name)
    {
        return $_COOKIE[$name];
    }
}

class cookie_statuses extends cookie_operations
{
    public $status;
    public $nameCookie;

    public function __construct($cookieName)
    {
        $this->nameCookie = $cookieName;

        if (isset($_POST['good'])) { //Получили согласие на запись
            $this->status = "write"; //Статус "Записывается"
            parent::set($cookieName, 'yes'); //Запишем
        } elseif (isset($_POST['nogood'])) { //Запрос на удаление
            $this->status = "delete"; //Статус "Удаляется"
            parent::del($cookieName); //Удалим
        } else {
            $this->status = "new";
        }
    }

    public function checkStatusCookie()
    {
        $cookieName = $_COOKIE[$this->nameCookie] || "";
        if ($this->status == "write") { //Проверим, не завершилась ли запись
            if (!empty($cookieName)) { //Если куки появились в записи
                $this->status = "written";  //Переводим в статус "Записано"
            }
        } elseif ($this->status == "delete") { //Проверим, не завершилось ли удаление
            if (empty($cookieName)) { //Если куки отстутствуют в записи
                $this->status = "deletion"; //Переводим в статус "Удалено"
            }
        } elseif ($this->status == "new") { //Если пользователь только вошел на сайт
            if (!empty($cookieName)) { //Проверяем, существует ли для него запись в куки 
                $this->status = "written"; //Если да, то переводим в статус "Записано   "
            }
        }

        return $this->status;
    }
}
