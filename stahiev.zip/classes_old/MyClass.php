<?
class MyClass
{
	function clearAllCache() { //функция очистки всего кеша сайта
		BXClearCache(true);

		if (class_exists('\Bitrix\Main\Data\ManagedCache')) {
			(new \Bitrix\Main\Data\ManagedCache())->cleanAll();
		}

		if (class_exists('\CStackCacheManager')) {
			(new \CStackCacheManager())->CleanAll();
		}

		if (class_exists('\Bitrix\Main\Data\StaticHtmlCache')) {
			\Bitrix\Main\Data\StaticHtmlCache::getInstance()->deleteAll();
		}
	}
	function searchid(&$arFields) { //функция добавления ID нового товара в поисковый индекс
		if (Bitrix\Main\Loader::includeModule("iblock")) {
			if ($arFields["ID"] > 0) {
				$upd = CIBlockElement::SetPropertyValuesEx(
					$arFields["ID"],
					$arFields['IBLOCK_ID'],
					array('SEARCH_ID' => $arFields["ID"])
				);
			}
		}
		//mail("test@test.test", "Функция searchid ОК", "Функция searchid ОК");
	}
	
	function AddOrderProperty_1($prop_id, $value, $order) {
		if (!strlen($prop_id)) {
			return false;
		}
		if (CModule::IncludeModule('sale')) {
			if ($arOrderProps = CSaleOrderProps::GetByID($prop_id)) {
				$db_vals = CSaleOrderPropsValue::GetList(array(), array('ORDER_ID' => $order, 'ORDER_PROPS_ID' => $arOrderProps['ID']));
				if ($arVals = $db_vals -> Fetch()) {
					return CSaleOrderPropsValue::Update($arVals['ID'], array(
					'NAME' => $arVals['NAME'],
					'CODE' => $arVals['CODE'],
					'ORDER_PROPS_ID' => $arVals['ORDER_PROPS_ID'],
					'ORDER_ID' => $arVals['ORDER_ID'],
					'VALUE' => $value,
					));
				} else {
					return CSaleOrderPropsValue::Add(array(
					'NAME' => $arOrderProps['NAME'],
					'CODE' => $arOrderProps['CODE'],
					'ORDER_PROPS_ID' => $arOrderProps['ID'],
					'ORDER_ID' => $order,
					'VALUE' => $value,
					));
				}
			}
		}
	}
}