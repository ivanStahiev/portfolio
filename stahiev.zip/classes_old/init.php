<?
//Подключаем класс MyClass и регистрируем обработчик события OnAfterIBlockElementAdd
if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/MyClass.php")) {
    require_once($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/MyClass.php");
    \Bitrix\Main\EventManager::getInstance()->addEventHandler("iblock", "OnAfterIBlockElementAdd", Array("MyClass", "searchid"));
}

//Подключаем класс MyClass1 и регистрируем обработчик события OnAdminSaleOrderViewDraggable
if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/MyClass1.php")) {
    //require_once($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/MyClass1.php");
    //\Bitrix\Main\EventManager::getInstance()->addEventHandler("main", "OnAdminSaleOrderViewDraggable", array("MyClass1", "onInit"));
}

//Подключаем класс CustomEvents и регистрируем обработчик события OnSaleComponentOrderOneStepComplete
if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/CustomEvents.php")) {
    require_once($_SERVER['DOCUMENT_ROOT'] . "/local/php_interface/include/CustomEvents.php");
    \Bitrix\Main\EventManager::getInstance()->addEventHandler('sale', 'OnSaleComponentOrderOneStepComplete', Array('CustomEvents', 'OnOrderAddHandler'));
}

function LogMessage($message, $label = '', $path = '')
{
    $backTrace = debug_backtrace();
    $logPathPart = array(
        'logs',
        date('Y'),
        date('m'),
        date('d'),
        date('H')
    );
    $logPath = $_SERVER['DOCUMENT_ROOT'] . '/';

    foreach ($logPathPart as $part) {
        $logPath .= $part . '/';

        if (!file_exists($logPath)) {
            mkdir($logPath);
        }
    }

    $path = $logPath . (mb_strlen($path) == 0 ? 'log.txt' : $path);
    $file = fopen($path, 'a');
    fwrite($file, date('r', time()) . "\t" . $label . ': ' . print_r($message, true) . " (line: " . $backTrace[0]['line'] . ", file: " . $backTrace[0]['file'] . ")\n");
}

function LogMessageDev($message, $label = '', $path = '')
{
    $backTrace = debug_backtrace();
    $logPathPart = array(
        'logsDev',
        date('Y'),
        date('m'),
        date('d'),
        date('H')
    );
    $logPath = $_SERVER['DOCUMENT_ROOT'] . '/';

    foreach ($logPathPart as $part) {
        $logPath .= $part . '/';

        if (!file_exists($logPath)) {
            mkdir($logPath);
        }
    }

    $path = $logPath . (mb_strlen($path) == 0 ? 'log.txt' : $path);
    $file = fopen($path, 'a');
    fwrite($file, date('r', time()) . "\t" . $label . ': ' . print_r($message, true) . " (line: " . $backTrace[0]['line'] . ", file: " . $backTrace[0]['file'] . ")\n");
}