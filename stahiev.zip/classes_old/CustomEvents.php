<?

class CustomEvents
{
	public function getNormPhone($phone)
	{
		$phone = preg_replace("/[^0-9]*/", '', $phone);
		if ((substr($phone, 0, 1) == '7') || (substr($phone, 0, 1) == '8')) {
			$phone = substr($phone, 1);
		}

		return $phone;
	}

	function OnOrderAddHandler($ID, $arFields)
	{
		//Получаем свойства заказа
		$arProps = array();
		$res = CSaleOrderPropsValue::GetOrderProps($arFields['ID']);
		while ($prop = $res->Fetch()) {
			$arProps[$prop['CODE']] = $prop;
		}

		//Запись нормированного телефона в свойство заказа ID 21 (PHONE_NO_SIMBOL)
		$normPhone = CustomEvents::getNormPhone($arProps['PHONE']['VALUE']);
		MyClass::AddOrderProperty_1(21, $normPhone, $arFields['ID']);

		//Запись IP-адреса в свойство заказа ID 9 (IP_USER)
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		MyClass::AddOrderProperty_1(9, $ip, $arFields['ID']);


		//Запись повторный/новый в свойство заказа ID 17 (NEW_REPLY)
		$arFilter = array('PROPERTY_VAL_BY_CODE_PHONE_NO_SIMBOL' => $normPhone, "STATUS_ID" => F);
		$db_sales = CSaleOrder::GetList(array("DATE_INSERT" => "ASC"), $arFilter);
		$i = 0;
		while ($ar_sales = $db_sales->Fetch()) {
			LogMessage($ar_sales, '$ar_sales2');
			/*echo "<pre>";
				echo print_r($ar_sales);
				echo "</pre>";*/
			$i++;
		}
		if ($i > 0) {
			MyClass::AddOrderProperty_1(17, 'Повторный клиент', $arFields['ID']);
		} else {
			MyClass::AddOrderProperty_1(17, 'Новый клиент', $arFields['ID']);
		}
	} //function OnOrderAddHandler($ID, $arFields)

	function SetCost($ORDER_ID)
	{
		if (!($arOrder = CSaleOrder::GetByID($ORDER_ID))) {
			mail("test@test.test", "SetCost", "Установить себестоимость по заказу " . $ORDER_ID . "не удалось");
			//return false;
		} else {
			//echo "<pre>";print_r($arOrder);echo "</pre>";
			$arOrderBasket = array();
			$arProductID = array();

			$dbBasket = CSaleBasket::GetList(
				array('NAME' => 'ASC'),
				array('ORDER_ID' => $arOrder["ID"]),
				false,
				false,
				array('ID', 'QUANTITY', 'PRODUCT_ID', 'ORDER_ID')
			);

			while ($arBasket = $dbBasket->GetNext()) {
				$arOrderBasket[$arBasket['PRODUCT_ID']] = intval($arBasket['QUANTITY']);
				//economy memory
				if (!in_array($arBasket['PRODUCT_ID'], $arProductID)) {
					$arProductID[] = $arBasket['PRODUCT_ID'];
				}
			}
			//echo "arOrderBasket<pre>";echo print_r($arOrderBasket);echo "</pre>";
			//echo "arProductID<pre>";echo print_r($arProductID);echo "</pre>";

			$productsCost = array();
			$dbProducts = CCatalogProduct::GetList(array(), array('ID' => $arProductID), false, false, array('ID', 'PURCHASING_PRICE'));
			while ($arProduct = $dbProducts->Fetch()) {
				$productsCost[$arProduct['ID']] = floatval($arProduct['PURCHASING_PRICE']);
			}
			//echo "<pre>";echo print_r($productsCost);echo "</pre>";
			$product_cost = 0;
			$delivery_cost = 0;
			$tax_cost = 0;

			foreach ($arOrderBasket as $productId => $quantity) {
				if (array_key_exists($productId, $productsCost) !== false) {
					$product_cost += $productsCost[$productId] * $quantity;
				}
			}
			//echo "product_cost - ".$product_cost."<br>";

			$delivery_cost = $arOrder['PRICE_DELIVERY'];
			if (($arOrder['PRICE_DELIVERY'] == 0) or ($arOrder['PRICE_DELIVERY'] == "")) $delivery_cost = 350;
			//echo "delivery_cost - ".$delivery_cost."<br>";

			$tax_cost = round($arOrder['PRICE'] * 0.06);
			//echo "tax_cost - ".$tax_cost."<br>";

			$COST_P = $product_cost;
			$COST_PD = $product_cost + $delivery_cost;
			$COST_PDT = $product_cost + $delivery_cost + $tax_cost;

			MyClass::AddOrderProperty_1(16, $COST_P, $arOrder["ID"]); //Себестоимость без доставки
			MyClass::AddOrderProperty_1(15, $COST_PD, $arOrder["ID"]); //Себестоимость с доставкой
			MyClass::AddOrderProperty_1(34, $COST_PDT, $arOrder["ID"]); //Себестоимость товар, доставка, налог
		}
	}
}
